#ifndef SCHEMA_RECORD_H
#define SCHEMA_RECORD_H
#include "../stddef.h"
#include "../shcema/table.h"
void get_reocrd(byte*, int*, struct table*, byte**);
#endif // !SCHEMA_RECORD_H
