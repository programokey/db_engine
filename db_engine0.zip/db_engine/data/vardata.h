#ifndef DATA_VARDATA_H
#define DATA_VARDATA_H
#include "../stddef.h"
void store_variable_data(byte* destination, byte* source);
#endif // !DATA_VARDATA_H