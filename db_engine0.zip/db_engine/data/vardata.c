#include "vardata.h"
void store_variable_data(byte* destination, byte* source)
{

}