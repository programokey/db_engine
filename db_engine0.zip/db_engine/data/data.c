#include "data.h"
struct data fix_length_data(int length, char* (*output_func)(byte*, int),void(*input_func)(char*, byte*, int*))
{
	struct data type;
	type.length = length;
	type.is_variable = false;
	type.input_func = input_func;
	type.output_func = output_func;
	return type;
}
struct data variable_length_data(int length, char* (*output_func)(byte*, int), void(*input_func)(char*, byte*, int*))
{
	struct data type;
	type.length = length;
	type.is_variable = true;
	type.input_func = input_func;
	type.output_func = output_func;
	return type;
}