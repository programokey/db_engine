#include <stdio.h>
#include <time.h>
#include "../db_engine/shcema/table.h"
#include "../db_engine/shcema/schema.h"
/*return a new sector to store variable length data*/
bool get_int_bit(int a, int i)
{
	return ((1 << i)&(a)) == 0? false:true;
}
void set_int_bit(int* a, int i, bool value)
{
	if (get_int_bit(*a, i) != value)
		(*a) ^= (1 << i);
}
void swap1(int* a, int* b)
{
	*a ^= *b;
	*b ^= *a;
	*a ^= *b;
}
void swap2(int* a, int* b)
{
	int c = *a;
	*a = *b;
	*b = c;
}

int main()
{
	return 0;
}
