#include "../stddef.h"
#define BALANCE_FACTOR  100
#define most  (BALANCE_FACTOR - 1)
#define internal_least  ((BALANCE_FACTOR - 1)/2)
#define leaf_least  BALANCE_FACTOR/2

struct b_plus_node
{
    bool is_leaf;
    int size;
    int key[BALANCE_FACTOR];
    struct b_plus_node* child[BALANCE_FACTOR + 1];
	struct b_plus_node* parent;
};
