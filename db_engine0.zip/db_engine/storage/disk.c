#include "../stddef.h"
#include "memory.h"
#include "disk.h"
#define PAGE_NUMBER (MEMORY_POOL_SIZE / PAGE_SIZE)

void flush(uint64_t location)
{
	fseek(file,0,location);
	fwrite(disk_to_memory(location),PAGE_SIZE,1,file);
}

struct memory_to_disk_item
{
	uint64_t p;
	bool dirty;
	uint16_t disk;
};

struct disk_to_memory_itme
{
	uint64_t location;
	uint16_t memory;
};

int item_num;
struct memory_to_disk_item memory_to_disk_table[PAGE_NUMBER];

struct disk_to_memory_itme disk_to_memor_table[PAGE_NUMBER];

void* swap_in(uint64_t location)
{
	if (item_num == PAGE_NUMBER) {
		int victim = rand() % PAGE_NUMBER;
		int k = memory_to_disk_table[victim].disk;
		if (memory_to_disk_table[victim].dirty)
			flush(disk_to_memor_table[k].location);
		memory_to_disk_table[victim].dirty = false;
		disk_to_memor_table[k].location = location;
		disk_to_memor_table[k].memory = (uint16_t)victim;
		for (; k > 0 && disk_to_memor_table[k].location < disk_to_memor_table[k - 1].location; k--) {
			swap(disk_to_memor_table[k - 1].location, disk_to_memor_table[k].location);
			swap(disk_to_memor_table[k - 1].memory, disk_to_memor_table[k].memory);
		}
		for (; k < PAGE_NUMBER - 1 && disk_to_memor_table[k].location > disk_to_memor_table[k + 1].location; k++) {
			swap(disk_to_memor_table[k + 1].location, disk_to_memor_table[k].location);
			swap(disk_to_memor_table[k + 1].memory, disk_to_memor_table[k].memory);
		}
		memory_to_disk_table[victim].disk = (uint16_t)k;
		fseek(file,0,location);
		fread((void*)memory_to_disk_table[victim].p,PAGE_SIZE,1,file);
		return (void*)memory_to_disk_table[victim].p;
	} else {
		int i = item_num;
		int j = item_num++;
		memory_to_disk_table[i].p = (uint64_t)get_page();
		memory_to_disk_table[i].dirty = false;
		disk_to_memor_table[j].location = location;
		for (; i > 0 && memory_to_disk_table[i].p < memory_to_disk_table[i - 1].p; i--) {
			swap(memory_to_disk_table[i].p, memory_to_disk_table[i - 1].p);
			swap(memory_to_disk_table[i].dirty, memory_to_disk_table[i - 1].dirty);
			swap(memory_to_disk_table[i].disk, memory_to_disk_table[i - 1].disk);
		}
		disk_to_memor_table[j].memory = (uint16_t)i;
		for (; j > 0 && disk_to_memor_table[j].location < disk_to_memor_table[j - 1].location; j--) {
			swap(disk_to_memor_table[j - 1].location, disk_to_memor_table[j].location);
			swap(disk_to_memor_table[j - 1].memory, disk_to_memor_table[j].memory);
		}
		memory_to_disk_table[i].disk = (uint16_t)j;
		fread((void*)memory_to_disk_table[i].p, PAGE_SIZE, 1, file);
		return (void*)memory_to_disk_table[i].p;
	}
}

int cur_node;
uint64_t get_disk_node()
{
	return 0;
}
uint64_t get_block()
{
	return 0;
}
void* disk_to_memory(uint64_t disk_pos)
{
	uint64_t left = disk_to_memor_table[0].location;
	uint64_t right = disk_to_memor_table[item_num - 1].location;
	uint64_t mid;
	while (left < right)
	{
		mid = left / 2 + right / 2 + (1l & left & right);
		if (disk_to_memor_table[mid].location == disk_pos) {
			return *(void**)&(memory_to_disk_table[disk_to_memor_table[mid].memory].p);
		} else if (disk_pos > disk_to_memor_table[mid].location) {
			left = mid + 1;
		} else {
			right = mid;
		}
	}
	return NULL;
}
uint64_t memory_to_disk(void* memory_pos)
{
	return 0;
}