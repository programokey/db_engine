#include <memory.h>
#include "memory.h"
#include "../stddef.h"
void* begin_of_memory_pool;
void* memroy_allocate(int size)
{
	return malloc(size);
}

void  release_memory(void* buffer)
{
	free(buffer);
}

void* get_page()
{
	return malloc(PAGE_SIZE);
}

void* get_memory_pool()
{
	begin_of_memory_pool =  malloc(MEMORY_POOL_SIZE + PAGE_SIZE);
	/*align to 64KB*/
	memory_pool = ((uint64_t)begin_of_memory_pool) % PAGE_SIZE ? begin_of_memory_pool :\
		(void*)(PAGE_SIZE - ((uint64_t)begin_of_memory_pool) % PAGE_SIZE + ((uint64_t)begin_of_memory_pool));
	return memory_pool;
}

void release_memory_pool()
{
	free(begin_of_memory_pool);
}

void memory_copy(byte* dest, byte* source, int length)
{
	word* d = (word*)dest;
	word* s = (word*)source;
	int word_num = length / sizeof(word);
	for (int i = 0; i < word_num; i++)
		d[i] = s[i];
	for (int i = 0; i < length%sizeof(word); i++)
		dest[word_num*sizeof(word) + i] = source[word_num*sizeof(word) + i];
}
