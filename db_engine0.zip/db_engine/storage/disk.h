#ifndef STORAGE_DISK_H
#define STORAGE_DISK_H
#include "../stddef.h"
#define NODE_SIZE 256
#define BYTE_PER_NODE (NODE_SIZE - 2*sizeof(uint16_t))
#define NODE_PER_NODE (NODE_SIZE/sizeof(uint64_t) - 1)
/*return a memory space corresponding to a disk spcace 
and set the disk space dirty*/
uint64_t get_disk_node();
uint64_t get_block();
void* disk_to_memory(uint64_t disk_pos);
uint64_t memory_to_disk(void* memory_pos);
/*flush drity block in memory to disk
*/
void flush(uint64_t);
#endif // !STORAGE_DISK_H