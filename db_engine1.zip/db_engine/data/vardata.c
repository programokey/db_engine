#include "vardata.h"
#include "../storage/disk.h"
void store_variable_data(byte* destination, byte* source)
{
	uint32_t length = *(uint32_t*)source;
	int node_needed = length / BYTE_PER_NODE;
	uint32_t* nodes = (uint32_t*)malloc(node_needed);
	for (int i = 0; i < node_needed;i++){

	}
}